for i in range(2, 1001):
    print(str(i)+" "+str(apakahPrima(i)))
